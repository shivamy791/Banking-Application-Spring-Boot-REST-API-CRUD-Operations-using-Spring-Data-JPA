package com.tgi.springBanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSoftwareApplicationTests {

	@Test
	void contextLoads() {
	}

}
