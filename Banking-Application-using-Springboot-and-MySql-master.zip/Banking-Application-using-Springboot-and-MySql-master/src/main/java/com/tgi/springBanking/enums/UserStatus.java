package com.tgi.springBanking.enums;

public class UserStatus {
	public static final boolean ActiveStatus=true; 
	public static final boolean InactiveStatus=false;

}
