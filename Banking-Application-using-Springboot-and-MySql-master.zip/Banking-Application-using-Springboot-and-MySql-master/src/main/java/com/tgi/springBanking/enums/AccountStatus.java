package com.tgi.springBanking.enums;

public enum AccountStatus {
	New,Approved,Rejected,Frozen,BlackList

}
