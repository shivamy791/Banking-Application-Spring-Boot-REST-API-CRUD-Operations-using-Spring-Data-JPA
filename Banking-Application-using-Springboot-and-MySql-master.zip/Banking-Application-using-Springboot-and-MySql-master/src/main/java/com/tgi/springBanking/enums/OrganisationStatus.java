package com.tgi.springBanking.enums;

public class OrganisationStatus {
	public static final boolean ActiveStatus=true; 
	public static final boolean InactiveStatus=false;

}
