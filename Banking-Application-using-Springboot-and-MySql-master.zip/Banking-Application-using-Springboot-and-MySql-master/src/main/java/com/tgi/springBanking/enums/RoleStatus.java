package com.tgi.springBanking.enums;

public class RoleStatus {
	public static final boolean ActiveStatus=true; 
	public static final boolean InactiveStatus=false;

}
