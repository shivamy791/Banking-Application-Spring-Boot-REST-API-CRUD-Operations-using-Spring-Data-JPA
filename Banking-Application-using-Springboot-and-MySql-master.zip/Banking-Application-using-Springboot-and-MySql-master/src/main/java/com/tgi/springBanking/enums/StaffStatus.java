package com.tgi.springBanking.enums;

public class StaffStatus {
	public static final boolean ActiveStatus=true; 
	public static final boolean InactiveStatus=false;

}
