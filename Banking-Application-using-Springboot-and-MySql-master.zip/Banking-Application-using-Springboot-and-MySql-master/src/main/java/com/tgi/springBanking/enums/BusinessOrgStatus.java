package com.tgi.springBanking.enums;

public class BusinessOrgStatus {
	public static final Boolean ActiveStatus=true; 
	public static final Boolean InactiveStatus=false;
}
