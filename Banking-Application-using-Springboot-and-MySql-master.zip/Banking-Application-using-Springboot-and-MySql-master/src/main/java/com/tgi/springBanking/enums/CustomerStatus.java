package com.tgi.springBanking.enums;


public class CustomerStatus {
	public static final boolean ActiveStatus=true; 
	public static final boolean InactiveStatus=false;

}
