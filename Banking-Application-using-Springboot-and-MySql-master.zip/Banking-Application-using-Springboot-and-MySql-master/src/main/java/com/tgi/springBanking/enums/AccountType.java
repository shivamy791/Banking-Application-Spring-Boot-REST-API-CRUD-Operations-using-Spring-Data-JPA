package com.tgi.springBanking.enums;

public enum AccountType {

	Savings,Business,Current
	
	

}
